def saludar():
    print('HEY')